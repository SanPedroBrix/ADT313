function Problem2() {
  const user = {
    name: 'San Pedro, Rovic Brix',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/f/fb/Reanne_Evans_PHC_2017-1.jpg',
    imageSize: 90,
  };

  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        input typre="Text"
        <img
          className='avatar'
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  function InitialContent() {
    return <h1>User profile is hidden.</h1>;
  }
  

  return (
    <>
      <div>
        <InitialContent />
        <button type='button'>Show Profile</button>
        
      </div>
     
    </>
  );
}

export default Problem2;
