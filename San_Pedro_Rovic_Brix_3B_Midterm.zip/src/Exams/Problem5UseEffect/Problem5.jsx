import React, { useState, useEffect } from 'react';

const UserActivity = () => {
  const [loading, setLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const [isIdle, setIsIdle] = useState(true);
  const [idleTimer, setIdleTimer] = useState(null);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 3000); 

    return () => clearTimeout(timeout); 
  }, []);

  useEffect(() => {
    const handleUserActivity = () => {
      setIsTyping(true);
      setIsIdle(false);

      if (idleTimer) {
        clearTimeout(idleTimer);
      }
      const newIdleTimer = setTimeout(() => {
        setIsIdle(true);
        setIsTyping(false);
      }, 2000); 

      setIdleTimer(newIdleTimer);
    };

    window.addEventListener('keydown', handleUserActivity);

    return () => {
      window.removeEventListener('keydown', handleUserActivity);
      if (idleTimer) {
        clearTimeout(idleTimer);
      }
    };
  }, [idleTimer]);

  return (
    <div>
      {}
      {loading && <div>Loading...</div>}

      {}
      {!loading && (
        <div>
          <h1>Welcome to the User Activity Detection Page</h1>
          <p>
            {isTyping ? 'User is typing...' : isIdle ? 'User is idle...' : 'User is active but not typing.'}
          </p>
          <input
            type="text"
            placeholder="Start typing to detect activity..."
            onChange={() => {}}
          />
        </div>
      )}
    </div>
  );
};

export default UserActivity;
