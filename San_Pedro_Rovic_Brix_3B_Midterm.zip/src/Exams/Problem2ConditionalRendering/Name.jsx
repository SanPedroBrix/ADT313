import { useState } from "react";
import ReactDOM from "react-dom/client";


function Name() {
  return (
    <>
      <h1>Name: San Pedro, Rovic Brix T</h1>
    </>
  )
}


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Name />);

              